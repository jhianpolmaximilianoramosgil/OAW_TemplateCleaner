#!/bin/bash
exec pwsh -ExecutionPolicy Unrestricted ./OAW-TC.ps1